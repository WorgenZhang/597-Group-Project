library('devtools')
library('roxygen2')
setwd('PMSgroup6')
document()
setwd('..')
install('PMSgroup6')
?PMS.test

